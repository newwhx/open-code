const ffi        = require('ffi');
const ref        = require('ref');
const StructType = require('ref-struct');
const ArrayType  = require('ref-array');
st_deviceInfo = StructType({
		szSeries               : ArrayType(ref.types.char, 12),                               
		szSerialNO             : ArrayType(ref.types.char, 48),                                 
		szMAC                  : ArrayType(ref.types.char, 20),                            
		szIPv4Address          : ArrayType(ref.types.char, 16),                                    
		szIPv4SubnetMask       : ArrayType(ref.types.char, 16),                                       
		dwDeviceType           : ref.types.uint, 
        dwPort                 : ref.types.uint, 
        dwNumberOfEncoders     : ref.types.uint, 
        dwNumberOfHardDisk     : ref.types.uint, 
		szDeviceSoftwareVersion: ArrayType(ref.types.char, 48),                                             
		szDSPVersion           : ArrayType(ref.types.char, 48),                                  
		szBootTime             : ArrayType(ref.types.char, 48),                                
		iResult                : ref.types.int,           
		szDevDesc              : ArrayType(ref.types.char, 24),                                       
		szOEMinfo              : ArrayType(ref.types.char, 24),                                     
		szIPv4Gateway          : ArrayType(ref.types.char, 16),                                     
		szIPv6Address          : ArrayType(ref.types.char, 46),                                     
		szIPv6Gateway          : ArrayType(ref.types.char, 46),                                     
		byIPv6MaskLen          : ref.types.uchar,
        bySupport              : ref.types.uchar,
        byDhcpEnabled          : ref.types.uchar,
        byDeviceAbility        : ref.types.uchar,
        wHttpPort              : ref.types.ushort,
		wDigitalChannelNum     : ref.types.ushort,
		szCmsIPv4              : ArrayType(ref.types.char, 16),
		wCmsPort               : ref.types.ushort,
		byOEMCode              : ref.types.uchar,
		byActivated            : ref.types.uchar,
		szBaseDesc             : ArrayType(ref.types.char, 24),                                   
		byRes                  : ArrayType(ref.types.uchar, 16),                    
});

console.log("beging to load lib...")
debugger
var libsadp = ffi.Library('../lib/libsadp.so', {
		// BOOL SADP_Start_V30(PDEVICE_FIND_CALLBACK pDeviceFindCallBack, int bInstallNPF , void *pUserData)
		'SADP_Start_V30' : ['bool', ['pointer', 'int', 'pointer']],

});

var devicesCnt = 0;
console.log("end to load lib...")
//// typedef void (__stdcall * PDEVICE_FIND_CALLBACK)(const SADP_DEVICE_INFO *lpDeviceInfo, void *pUserData)
 deviceFindCallBack = ffi.Callback('void', [ref.refType(st_deviceInfo), 'pointer'],
		function(pDeviceInfo, pUserData){
				
				devicesCnt++;
				//save device info to global buf
				//pDeviceinfo.refdef();	
				console.log("In the call back function");
		}
);

var DeviceInfoArr = ArrayType(st_deviceInfo);
var buf = new Buffer(st_deviceInfo.size * 100);
var astDeviceInfo = DeviceInfoArr.untilZeros(buf);

console.log("registering the callback");
ret = libsadp.SADP_Start_V30(deviceFindCallBack, 0, buf);
console.log("call back register result:" + ret);

